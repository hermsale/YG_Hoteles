import './bootstrap';
import './calendario-mes.js';


import Alpine from 'alpinejs';
import './calendario.js';


window.Alpine = Alpine;

Alpine.start();
