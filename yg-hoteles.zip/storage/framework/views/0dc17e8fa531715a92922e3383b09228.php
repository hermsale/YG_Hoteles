<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-gray-200 text-black pt-32 pb-16" x-data="{ tab: 'clientes' }">
        <div class="max-w-6xl mx-auto px-4">

            <div class="flex justify-between items-center mb-6">
                <h2 class="text-3xl font-bold">Gestión de Usuarios</h2>
                <a href="<?php echo e(route('backoffice.usuarios.crear')); ?>"
                    class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-semibold">
                    ➕ Agregar usuario
                </a>
            </div>

            <!-- Tabs -->
            <div class="flex space-x-4 mb-8">
                <button
                    @click="tab = 'clientes'"
                    :class="tab === 'clientes'
                        ? 'bg-gray-700 text-white'
                        : 'bg-white text-gray-800 hover:bg-gray-400'"
                    class="px-4 py-2 rounded-lg font-semibold transition-colors duration-200">
                    Clientes
                </button>

                <button
                    @click="tab = 'empleados'"
                    :class="tab === 'empleados'
                        ? 'bg-gray-700 text-white'
                        : 'bg-white text-gray-800 hover:bg-gray-400'"
                    class="px-4 py-2 rounded-lg font-semibold transition-colors duration-200">
                    Empleados
                </button>

            </div>
            <?php if(session('success')): ?>
            <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 4000)" x-show="show"
                class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg shadow-sm text-center transition">
                <strong class="font-bold">✔️ ¡Éxito!</strong>
                <span class="ml-2"><?php echo e(session('success')); ?></span>
            </div>
            <?php endif; ?>
            <!-- Clientes -->
            <div x-show="tab === 'clientes'" x-transition>
                <?php $__empty_1 = true; $__currentLoopData = $usuarios->where('rol.nombre_rol', 'Cliente'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-gray-100 text-black rounded-lg shadow p-6 mb-6 flex justify-between items-center">
                    <div>
                        <p class="font-bold text-lg">Nombre: <?php echo e($usuario->name); ?></p>
                        <p class="font-bold text-sm">Email: <?php echo e($usuario->email); ?></p>
                    </div>

                    <div class="flex gap-2">
                        <!-- Botón reset clave -->
                        <form action="<?php echo e(route('backoffice.usuarios.resetearClave', $usuario->id)); ?>" method="POST"
                            onsubmit="return confirm('¿Asignar nueva contraseña a <?php echo e($usuario->email); ?>?')">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="bg-yellow-600 hover:bg-yellow-700 text-white px-3 py-1 rounded text-sm">
                                🔑 Nueva clave
                            </button>
                        </form>

                        <!-- Botón eliminar -->
                        <form action="<?php echo e(route('backoffice.usuarios.destroy', $usuario->id)); ?>" method="POST"
                            onsubmit="return confirm('¿Eliminar a <?php echo e($usuario->name); ?>?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm">
                                🗑️ Eliminar
                            </button>
                        </form>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center text-gray-300">No hay clientes registrados aún.</p>
                <?php endif; ?>
            </div>

            <!-- Empleados -->
            <div x-show="tab === 'empleados'" x-transition>
                <?php $__empty_1 = true; $__currentLoopData = $usuarios->where('rol.nombre_rol', '==', 'Recepcionista'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-gray-100 text-black rounded-lg shadow p-6 mb-6 flex justify-between items-center">
                    <div>
                        <p class="font-bold text-lg">Nombre: <?php echo e($usuario->name); ?></p>
                        <p class="font-bold text-sm">Email: <?php echo e($usuario->email); ?> - Rol: <?php echo e($usuario->rol->nombre_rol); ?></p>
                    </div>

                    <div class="flex gap-2">
                        <!-- Botón reset clave -->
                        <form action="<?php echo e(route('backoffice.usuarios.resetearClave', $usuario->id)); ?>" method="POST"
                            onsubmit="return confirm('¿Asignar nueva contraseña a <?php echo e($usuario->name); ?>?')">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="bg-yellow-600 hover:bg-yellow-700 text-white px-3 py-1 rounded text-sm">
                                🔑 Nueva clave
                            </button>
                        </form>

                        <!-- Botón eliminar -->
                        <form action="<?php echo e(route('backoffice.usuarios.destroy', $usuario->id)); ?>" method="POST"
                            onsubmit="return confirm('¿Eliminar a <?php echo e($usuario->name); ?>?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm">
                                🗑️ Eliminar
                            </button>
                        </form>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center text-gray-300">No hay empleados registrados aún.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/backoffice/usuarios/index.blade.php ENDPATH**/ ?>