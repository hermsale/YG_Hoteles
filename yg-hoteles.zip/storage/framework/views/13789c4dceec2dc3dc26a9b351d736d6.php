<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="relative min-h-screen bg-cover bg-center"
        style="background-image: url('<?php echo e(asset('img/otros/fondo-inicio.png')); ?>');">

        <div class="py-24 px-4 bg-black bg-opacity-50">
            <div class="max-w-6xl mx-auto bg-white bg-opacity-95 rounded-2xl shadow-xl p-8">

                
                <h2 class="text-2xl font-bold text-gray-800 mb-6">
                    📌 Reservas en Curso
                </h2>

                
                <?php if(session('success')): ?>
                <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 4000)" x-show="show"
                    class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg shadow-sm"
                    role="alert">
                    <strong class="font-bold">✔️ ¡Éxito!</strong>
                    <span class="ml-2"><?php echo e(session('success')); ?></span>
                </div>
                <?php endif; ?>

                
                <div class="overflow-x-auto rounded-lg shadow-md border border-gray-300">
                    <table class="min-w-full text-sm text-gray-900">
                        <thead class="bg-gray-100 text-left text-gray-700 uppercase text-xs tracking-wider">
                            <tr>
                                <th class="px-4 py-3">Fecha de compra</th>
                                <th class="px-4 py-3">Estado Reserva</th>
                                <th class="px-4 py-3">Estado Pago</th>
                                <th class="px-4 py-3">Habitación</th>
                                <th class="px-4 py-3">Fecha Ingreso</th>
                                <th class="px-4 py-3">Fecha Egreso</th>
                                <th class="px-4 py-3">Importe Total</th>
                                <th class="px-4 py-3 text-center">Detalle</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 bg-white">
                            <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 transition">
                                
                                <td class="px-4 py-3">
                                    <?php echo e(\Carbon\Carbon::parse($reserva->fecha_creacion)->format('d/m/Y H:i')); ?>

                                </td>

                                
                                <td class="px-4 py-3">
                                    <span class="font-semibold
                            <?php if($reserva->estado_reserva === 'Activa'): ?> text-green-600
                            <?php elseif($reserva->estado_reserva === 'pendiente'): ?> text-yellow-600
                            <?php elseif($reserva->estado_reserva === 'Finalizada'): ?> text-blue-600
                            <?php elseif($reserva->estado_reserva === 'Cancelada'): ?> text-red-600
                            <?php else: ?> text-gray-600 <?php endif; ?>">
                                        <?php echo e($reserva->estado_reserva); ?>

                                    </span>
                                </td>

                                
                                <td class="px-4 py-3">
                                    <span class="font-semibold
                            <?php if($reserva->estado_pago === 'Pagado'): ?> text-green-600
                            <?php elseif($reserva->estado_pago === 'Pendiente'): ?> text-yellow-600
                            <?php elseif($reserva->estado_pago === 'Cancelado'): ?> text-red-600
                            <?php else: ?> text-gray-600 <?php endif; ?>">
                                        <?php echo e($reserva->estado_pago); ?>

                                    </span>
                                </td>

                                
                                <td class="px-4 py-3">
                                    <?php echo e($reserva->habitacion->codigo_habitacion); ?> - <?php echo e($reserva->habitacion->categoria->nombre); ?>

                                </td>

                                
                                <td class="px-4 py-3"><?php echo e(\Carbon\Carbon::parse($reserva->fecha_ingreso)->format('d/m/Y')); ?></td>
                                <td class="px-4 py-3"><?php echo e(\Carbon\Carbon::parse($reserva->fecha_egreso)->format('d/m/Y')); ?></td>

                                
                                <td class="px-4 py-3 font-medium">
                                    $<?php echo e(number_format($reserva->precio_final, 2, ',', '.')); ?>

                                </td>

                                
                                <td class="px-4 py-3 text-center">
                                    <a href="<?php echo e(route('reservas.detalleReserva', $reserva->id)); ?>"
                                        class="text-blue-600 hover:underline font-semibold">
                                        Ver detalles
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>


            </div>
        </div>


    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/cliente/reservas/index.blade.php ENDPATH**/ ?>