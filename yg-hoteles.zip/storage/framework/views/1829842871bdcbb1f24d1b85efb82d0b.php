<?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img src="<?php echo e(asset($imagen->url)); ?>" alt="Imagen" class="w-32 h-32 object-cover rounded">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/imagenes/listado.blade.php ENDPATH**/ ?>