<div>
    <!--[if BLOCK]><![endif]--><?php if($mostrarModal): ?>
        <div class="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
            <div class="bg-white text-black rounded-lg shadow p-6 max-w-lg w-full">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-bold">Confirmar Reserva</h2>
                    <button wire:click="cerrarModal" class="text-gray-500 hover:text-red-600 text-xl">&times;</button>
                </div>
                <p>Contenido del modal</p>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views\livewire/confirmar-reserva-modal.blade.php ENDPATH**/ ?>