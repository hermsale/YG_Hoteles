
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Hero Section con imagen de fondo -->
    <section class="relative h-screen bg-cover bg-center"
            style="background-image: url('<?php echo e(asset('img/otros/fondo-inicio.png')); ?>');">
            <div class="absolute inset-0 bg-black bg-opacity-40"></div>
            <div class="relative z-10 flex justify-center items-center h-full">
                <div class="bg-white text-black p-6 rounded shadow-lg w-80">
                    <h2 class="text-lg font-semibold mb-4">Reserva Online</h2>
                    <form>
                        <label class="block text-sm">Fecha de entrada</label>
                        <input type="date" class="w-full border rounded p-1 mb-3" value="2025-04-03">

                        <label class="block text-sm">Fecha de salida</label>
                        <input type="date" class="w-full border rounded p-1 mb-3" value="2025-04-04">

                        <label class="block text-sm">Huéspedes</label>
                        <select class="w-full border rounded p-1">
                            <option>2 Adultos</option>
                            <option>3 Adultos</option>
                            <option>4 Adultos</option>
                        </select>

                        <button type="submit" class="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded">
                            Buscar
                        </button>
                    </form>
                </div>
            </div>
        </section>

 <!-- cito el componente de navbar -->
    <?php if (isset($component)) { $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e = $attributes; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $attributes = $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $component = $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>

    <!-- Sección de habitaciones -->
    <section class="bg-gray-900 text-white py-16">
        <div class="max-w-6xl mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-6">Detalles y Precios</h2>
            <p class="text-center max-w-6xl mx-auto mb-12">
                YGHoteles ofrece 15 exclusivas habitaciones diseñadas para brindar confort y descanso en el corazón de Las Leñas. Algunas de ellas cuentan con balcones privados con vista a las montañas, y están equipadas con minibar y zona de comedor para quienes prefieren opciones de autoservicio.
                Cada habitación ha sido cuidadosamente insonorizada e incluye un amplio escritorio, ideal tanto para el relax como para el trabajo. Los baños están equipados con bañera y ducha, además de artículos de tocador de cortesía. Algunas habitaciones también ofrecen vistas panorámicas al entorno natural de la cordillera, creando una experiencia única de conexión con la montaña.
            </p>

            <!-- Repetí este bloque por habitación -->
            <div class="bg-gray-100 text-black rounded-lg shadow p-6 mb-10 flex flex-col md:flex-row gap-6">
                <img src="/img/habitaciones/habitacion-deluxe101-1.png" alt="Habitación Deluxe" class="w-full md:w-1/3 rounded-lg object-cover">
                <div class="md:w-2/3">
                    <h3 class="text-xl font-bold mb-2">Habitación Deluxe con Vista a la Montaña</h3>
                    <p class="mb-4">Disfruta del máximo confort en nuestra Habitación Deluxe, diseñada para dos huéspedes y con un espacio de 30 m². Su elegante diseño     combina tonos cálidos y una iluminación acogedora, ideal para una estancia relajante.
                    Cuenta con una amplia ventana con vistas panorámicas a las montañas, permitiéndote disfrutar de la belleza natural de Las Leñas desde la comodidad de tu habitación.
                    </p>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm mb-4">
                        <ul class="list-disc list-inside">
                            <p><strong> Servicios incluidos: </strong></p>
                            <li>Cama King size</li>
                            <li>Zona de estar con sillones y mesa auxiliar</li>
                            <li>Baño privado con ducha y bañera</li>
                            <li>Smart TV</li>
                            <li>Wi-Fi de alta velocidad</li>
                            <li>Minibar y set de café/té</li>
                            <li>Escritorio para trabajo o lectura</li>
                            <li>Aire acondicionado y calefacción</li>
                            <li>Caja de seguridad</li>
                        </ul>
                        <div>
                            <p>Capacidad de huéspedes: <strong> 2 </strong></p>
                            <p>Código habitación: <strong> 01 - Deluxe </strong> </p>
                        </div>

                    </div>

                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                        <p><strong>Precio por 1 noche:</strong> <span class="text-green-700 font-semibold">90000 ARS</span></p>
                        <a href="#" class="mt-2 sm:mt-0 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Reservar Ahora</a>
                    </div>
                </div>
            </div>
            <!-- Fin de habitación -->

            <!-- Repetí este bloque por habitación -->
            <div class="bg-gray-100 text-black rounded-lg shadow p-6 mb-10 flex flex-col md:flex-row gap-6">
                <img src="/img/Habitaciones/habitacion-simple201-1.png" alt="Habitación Estándar" class="w-full md:w-1/3 rounded-lg object-cover">
                <div class="md:w-2/3">
                    <h3 class="text-xl font-bold mb-2">Habitación Estándar con Vista Panorámica</h3>
                    <p class="mb-4">Nuestra Habitación Estándar es el equilibrio perfecto entre comodidad y estilo. Diseñada para dos huéspedes, cuenta con un espacio de 25 m², con una decoración moderna y acogedora en tonos neutros que invitan al descanso.
La habitación dispone de una ventana amplia, permitiendo la entrada de luz natural y ofreciendo una vista relajante hacia el entorno montañoso de Las Leñas.</p>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm mb-4">
                        <ul class="list-disc list-inside">
                            <p><strong> Servicios incluidos: </strong></p>
                            <li>Cama Queen size</li>
                            <li>Baño privado con ducha</li>
                            <li>TV de pantalla plana con canales por cable</li>
                            <li>Wi-Fi de alta velocidad</li>
                            <li>Escritorio y mesitas de noche</li>
                            <li>Ventilador de techo y calefacción</li>
                            <li>Caja de seguridad</li>
                        </ul>
                        <div>
                            <p>Capacidad de huéspedes: <strong> 2 </strong></p>
                            <p>Código habitación: <strong> 02 - Estándar </strong> </p>
                        </div>

                    </div>

                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                        <p><strong>Precio por 1 noche:</strong> <span class="text-green-700 font-semibold">60000 ARS</span></p>
                        <a href="#" class="mt-2 sm:mt-0 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Reservar Ahora</a>
                    </div>
                </div>
            </div>
            <!-- Fin de habitación -->

        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/cliente/habitaciones/habitaciones.blade.php ENDPATH**/ ?>