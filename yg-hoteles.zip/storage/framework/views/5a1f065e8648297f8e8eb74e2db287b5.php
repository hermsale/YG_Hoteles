<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-gray-900 text-white pt-32 pb-16">
        <div class="max-w-4xl mx-auto bg-white rounded-lg shadow p-6 text-black">
            <h2 class="text-2xl font-bold mb-6">Editar Habitación</h2>
            <form action="<?php echo e(route('backoffice.habitaciones.update', $habitacion)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <div class="mb-4">
                    <label class="block font-semibold mb-1">Nombre</label>
                    <input type="text" name="nombre" value="<?php echo e(old('nombre', $habitacion->nombre)); ?>"
                        class="w-full border rounded px-3 py-2">
                </div>

                
                <div class="mb-4">
                    <label class="block font-semibold mb-1">Descripción</label>
                    <textarea name="descripcion" rows="3" class="w-full border rounded px-3 py-2"><?php echo e(old('descripcion', $habitacion->descripcion)); ?></textarea>
                </div>

                
                <div class="mb-4">
                    <label class="block font-semibold mb-1">Categoría</label>
                    <select name="categoria_id" class="w-full border rounded px-3 py-2">
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categoria->id); ?>"
                            <?php echo e($habitacion->categoria_id == $categoria->id ? 'selected' : ''); ?>>
                            <?php echo e($categoria->nombre); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="mb-4">
                    <label class="block font-semibold mb-1">Capacidad</label>
                    <input type="number" name="capacidad" value="<?php echo e(old('capacidad', $habitacion->capacidad)); ?>"
                        class="w-full border rounded px-3 py-2">
                </div>

                
                <div class="mb-4">
                    <label class="block font-semibold mb-1">Precio por noche (ARS)</label>
                    <input type="number" step="0.01" name="precio_noche" value="<?php echo e(old('precio_noche', $habitacion->precio_noche)); ?>"
                        class="w-full border rounded px-3 py-2">
                </div>

                
                <div class="mb-6">
                    <label class="block font-semibold mb-2">Servicios incluidos</label>
                    <div class="grid grid-cols-2 gap-2">
                        <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center space-x-2">
                            <input type="checkbox" name="amenities[]" value="<?php echo e($amenity->id); ?>"
                                <?php echo e($habitacion->amenities->contains($amenity->id) ? 'checked' : ''); ?>>
                            <span><?php echo e($amenity->nombre); ?></span>
                        </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                
                <div class="mb-6">
                    <label class="block font-semibold mb-1">Imágenes actuales</label>
                    <div class="flex flex-wrap gap-2 mb-2">
                        <?php $__currentLoopData = $habitacion->imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="relative w-32 h-20">
                            <img src="<?php echo e(asset($imagen->url)); ?>" class="w-full h-full object-cover rounded">
                            <button type="button"
                                onclick="document.getElementById('delete-imagen-<?php echo e($imagen->id); ?>').submit();"
                                class="absolute top-1 right-1 bg-red-600 text-white rounded px-1 text-xs">
                                ✖
                            </button>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <label class="block font-semibold mb-1">Agregar nuevas imágenes</label>
                    <input type="file" name="imagenes[]" multiple class="w-full border rounded px-3 py-2">
                </div>

                
                <div class="flex justify-between mt-6">
                    <a href="<?php echo e(route('backoffice.habitaciones.index')); ?>"
                        class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded">⬅️ Cancelar</a>

                    <div class="flex gap-3">
                        <button type="submit"
                            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">💾 Guardar</button>
                    </div>

            </form>
        </div>
        <div class="text-center mt-8">
            <h3 class="text-lg font-semibold mt-8">Eliminar Habitación</h3>
            <p class="text-red-600 mb-4">Esta acción eliminará la habitación y todas sus imágenes asociadas.</p>
            <form action="<?php echo e(route('backoffice.habitaciones.destroy', $habitacion)); ?>" method="POST"
                onsubmit="return confirm('¿Estás seguro de que deseas eliminar esta habitación?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit"
                    class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded">🗑️ Eliminar</button>
            </form>
        </div>
        <?php $__currentLoopData = $habitacion->imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form id="delete-imagen-<?php echo e($imagen->id); ?>"
            action="<?php echo e(route('backoffice.habitaciones.imgDestroy', $imagen->id)); ?>"
            method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/backoffice/habitaciones/editar.blade.php ENDPATH**/ ?>