<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-gray-900 text-white pt-32 pb-16">
        <div class="max-w-4xl mx-auto bg-white rounded-lg shadow p-6 text-black">
            <h2 class="text-2xl font-bold mb-6">Crear Nueva Habitación</h2>

            <form action="<?php echo e(route('backoffice.habitaciones.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                
                <div class="mb-4">
                    <label class="block font-semibold mb-1">Nombre</label>
                    <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>"
                        class="w-full border rounded px-3 py-2" required>
                </div>

                
                <div class="mb-4">
                    <label class="block font-semibold mb-1">Descripción</label>
                    <textarea name="descripcion" rows="3" class="w-full border rounded px-3 py-2" required><?php echo e(old('descripcion')); ?></textarea>
                </div>

                
                <div class="mb-4">
                    <label class="block font-semibold mb-1">Categoría</label>
                    <select name="id_categoria" class="w-full border rounded px-3 py-2" required>
                        <option value="">-- Seleccionar --</option>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categoria->id); ?>" <?php echo e(old('id_categoria') == $categoria->id ? 'selected' : ''); ?>>
                            <?php echo e($categoria->nombre); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="mb-4">
                    <label class="block font-semibold mb-1">Capacidad</label>
                    <input type="number" name="capacidad" value="<?php echo e(old('capacidad')); ?>"
                        class="w-full border rounded px-3 py-2" required min="1">
                </div>

                
                <div class="mb-4">
                    <label class="block font-semibold mb-1">Código de habitación</label>
                    <input type="text" name="codigo_habitacion" value="<?php echo e(old('codigo_habitacion')); ?>"
                        class="w-full border rounded px-3 py-2" required>
                </div>

                
                <div class="mb-4">
                    <label class="block font-semibold mb-1">Precio por noche (ARS)</label>
                    <input type="number" step="0.01" name="precio_noche" value="<?php echo e(old('precio_noche')); ?>"
                        class="w-full border rounded px-3 py-2" required>
                </div>

                
                <div class="mb-6">
                    <label class="block font-semibold mb-2">Servicios incluidos</label>
                    <div class="grid grid-cols-2 gap-2">
                        <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center space-x-2">
                            <input type="checkbox" name="amenities[]" value="<?php echo e($amenity->id); ?>"
                                <?php echo e(in_array($amenity->id, old('amenities', [])) ? 'checked' : ''); ?>>
                            <span><?php echo e($amenity->nombre); ?></span>
                        </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                
                <div class="mb-6">
                    <label class="block font-semibold mb-1">Agregar imágenes</label>
                    <input type="file" name="imagenes[]" multiple class="w-full border rounded px-3 py-2">
                </div>

                
                <div class="flex justify-between mt-6">
                    <a href="<?php echo e(route('backoffice.habitaciones.index')); ?>"
                        class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded">⬅️ Cancelar</a>

                    <button type="submit"
                        class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">➕ Crear Habitación</button>
                </div>
            </form>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/backoffice/habitaciones/crear.blade.php ENDPATH**/ ?>