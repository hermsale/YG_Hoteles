<div>
    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-center mb-6">
        
        <div class="bg-white rounded-xl p-4 shadow border">
            <p class="text-2xl font-bold text-green-600"><?php echo e($totalLlegadas); ?></p>
            <p class="text-sm text-gray-600">LLEGADAS</p>
        </div>

        
        <div class="bg-white rounded-xl p-4 shadow border">
            <p class="text-2xl font-bold text-red-600"><?php echo e($totalSalidas); ?></p>
            <p class="text-sm text-gray-600">SALIDAS</p>
        </div>

        
        <div class="bg-white rounded-xl p-4 shadow border">
            <p class="text-2xl font-bold text-blue-600"><?php echo e($totalAlojados); ?></p>
            <p class="text-sm text-gray-600">HABITACIONES RESERVADAS</p>
        </div>
    </div>

    
    <div class="flex gap-2 text-sm mb-2">
        <button wire:click="setFiltro('llegadas')" class="px-2 py-1 rounded <?php echo e($filtro === 'llegadas' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'); ?>">
            Llegadas
        </button>
        <button wire:click="setFiltro('salidas')" class="px-2 py-1 rounded <?php echo e($filtro === 'salidas' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'); ?>">
            Salidas
        </button>
        <button wire:click="setFiltro('alojados')" class="px-2 py-1 rounded <?php echo e($filtro === 'alojados' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'); ?>">
            Huéspedes Alojados
        </button>
    </div>

    
    <table class="w-full text-sm">
        <thead>
            <tr class="text-left text-gray-600 border-b">
                <th>Huésped</th>
                <th>Reserva</th>
                <th>Habitación</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b">
                    <td class="py-2 text-blue-600"><?php echo e($reserva->usuario->name ?? 'N/A'); ?></td>
                    <td class="py-2 text-blue-600">#<?php echo e($reserva->id); ?></td>
                    <td class="py-2 text-blue-600"><?php echo e($reserva->habitacion->nombre ?? 'N/A'); ?></td>
                    <td class="flex gap-2 items-center">
                        <!--[if BLOCK]><![endif]--><?php if($reserva->check_in): ?>
                            <span class="text-green-600">Check-in hecho</span>
                        <?php else: ?>
                            <span class="text-yellow-600">Pendiente</span>
                            <button wire:click="hacerCheckIn(<?php echo e($reserva->id); ?>)"
                                    class="text-xs bg-blue-500 text-white rounded px-2 py-1 hover:bg-blue-600 transition">
                                Check In
                            </button>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        
                       <button wire:click="cancelarCheckIn(<?php echo e($reserva->id); ?>)"
                            class="text-xs bg-red-500 text-white rounded px-2 py-1 hover:bg-red-600 transition">
                        Cancelar
                    </button>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center text-gray-400 py-4">No hay reservas registradas</td>
                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/livewire/dashboard-reservas.blade.php ENDPATH**/ ?>