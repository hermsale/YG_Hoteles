<div>

    <!--[if BLOCK]><![endif]--><?php if(count($habitaciones) > 0): ?>
    <div class="mt-10 space-y-10">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $habitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-gray-100 text-black rounded-lg shadow p-6 flex flex-col md:flex-row gap-6">
            <?php $imagen = $habitacion->imagenes->first(); ?>

            
            <img src="<?php echo e(asset($imagen->url ?? asset('img/otros/no-image.png'))); ?>"
                class="w-full md:w-1/3 max-h-64 object-cover rounded-lg">

            <div class="md:w-2/3">
                <h3 class="text-xl font-bold mb-2"><?php echo e($habitacion->nombre); ?></h3>
                <p class="mb-4"><?php echo e($habitacion->descripcion); ?></p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm mb-4">
                    <ul class="list-disc list-inside">
                        <p><strong>Servicios incluidos:</strong></p>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $habitacion->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li><?php echo e($amenity->nombre); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li>Sin servicios listados</li>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                    <div>
                        <p>Capacidad: <strong><?php echo e($habitacion->capacidad); ?></strong></p>
                        <p>Categoría: <strong><?php echo e($habitacion->categoria->nombre ?? 'Sin categoría'); ?></strong></p>
                        <p>Código: <strong><?php echo e($habitacion->codigo_habitacion); ?></strong></p>
                    </div>
                </div>

                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <p><strong>Precio por noche:</strong>
                        <span class="text-green-700 font-semibold">
                            <?php echo e(number_format($habitacion->precio_noche, 2, ',', '.')); ?> ARS
                        </span>
                    </p>
                </div>
                <button onclick="Livewire.dispatch('abrir-modal-reserva', {
                        component: 'confirmar-reserva-modal',
                        nombreHabitacion: '<?php echo e($habitacion->nombre); ?>',
                        capacidad: '<?php echo e($habitacion->capacidad); ?>',
                        codigo_habitacion: '<?php echo e($habitacion->codigo_habitacion); ?>',
                        imagenUrl: '<?php echo e($imagen->url); ?>',
                        fechaEntrada: '<?php echo e($fechaEntrada); ?>',
                        fechaSalida: '<?php echo e($fechaSalida); ?>',
                        precioNoche: '<?php echo e($habitacion->precio_noche); ?>',
                        })" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                    Reservar Ahora
                </button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <?php else: ?>
    <p class="mt-4 text-gray-600">No hay habitaciones disponibles.</p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/livewire/listado-habitaciones.blade.php ENDPATH**/ ?>