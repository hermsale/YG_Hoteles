<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    
    <?php $__env->startPush('head'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="offset-base" content="<?php echo e($fechas->keys()->first()); ?>">
    <meta name="fecha-min-calendario" content="<?php echo e(\Carbon\Carbon::parse($rango->fecha_inicio)->format('Y-m-d')); ?>">
    <meta name="fecha-max-calendario" content="<?php echo e(\Carbon\Carbon::parse($rango->fecha_fin)->format('Y-m-d')); ?>">
    <?php $__env->stopPush(); ?>

    <div class="pt-28 px-4 md:px-6">
        <div class="calendario-container">


            
            <?php
            $rol = Auth::check() ? Auth::user()->rol->nombre_rol : null;
            ?>

            <?php if($rol === 'Administrador' || $rol === 'Recepcionista'): ?>
            <div class="mb-4 flex items-center gap-3">
                <input type="date" id="inputFechaIr"
                    class="border px-3 py-1 rounded shadow-sm w-40"
                    value="<?php echo e($fechaBase->format('Y-m-d')); ?>">

                <button type="button"
                    id="btnIrFecha"
                    class="bg-blue-500 text-white px-3 py-1 rounded">
                    Ir a fecha
                </button>

                


            </div>
            <?php endif; ?>


            
            <div id="mes-actual"
                class="text-lg font-bold uppercase text-center text-gray-800 mb-3">
                <?php echo e(mb_strtoupper($fechaBase->translatedFormat('F Y'), 'UTF-8')); ?>

            </div>

            
            <div class="overflow-x-auto relative calendario-scroll">
                <table class="min-w-[1500px] table-auto border-collapse bg-white" id="tabla-calendario">
                    <thead>
                        
                        <tr>
                            <th id="th-habitacion" class="sticky left-0 z-10 bg-gray-100 border border-gray-300 text-left px-2">
                                Habitación
                            </th>
                            <?php $__currentLoopData = $fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th
                                class="fecha-col text-center align-top border border-gray-300 px-2 py-1 min-w-[9.5rem]"
                                data-fecha="<?php echo e($fecha->toDateString()); ?>">
                                <div class="flex flex-row justify-center gap-1 text-[13px] font-semibold uppercase">
                                    <span><?php echo e($fecha->translatedFormat('l')); ?></span>
                                    <span><?php echo e($fecha->translatedFormat('d')); ?></span>
                                </div>
                            </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        
                        <tr>
                            <th class="sticky left-0 bg-gray-50 text-gray-500 text-sm border border-gray-300 px-2">
                                <span class="text-[12px]">Porcentaje de ocupación</span>
                            </th>
                            <?php $__currentLoopData = $fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="text-gray-400 text-xs py-1 border border-gray-100">
                                <?php echo e($ocupaciones[$fecha->toDateString()] ?? 0); ?>%
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $habitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="h-20 border-t fila-habitacion" data-habitacion-id="<?php echo e($habitacion->id); ?>">

                            
                            <td class="sticky left-0 bg-white border border-gray-300 text-left px-2 font-semibold">
                                <?php echo e($habitacion->nombre); ?>

                            </td>

                            
                            <?php $__currentLoopData = $fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $ocupada = $habitacion->reservas()
                            ->whereDate('fecha_ingreso', '<=', $fecha)
                                ->whereDate('fecha_egreso', '>', $fecha)
                                ->exists();
                                $precio = $habitacion->precio_noche ?? 100;
                                ?>
                                <td class="relative border border-gray-200 text-[11px] text-center p-1 bg-white">
                                    $<?php echo e(number_format($precio, 0, ',', '.')); ?><br>
                                    <span class="font-bold"><?php echo e($ocupada ? 0 : 1); ?></span>
                                    <div class="overlay-reserva absolute inset-0"></div>
                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


                
                <div id="layer-pills-reservas" class="absolute top-0 left-0 w-full h-full z-20">

                    <?php $__currentLoopData = $habitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitacionIndex => $habitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $reservas[$habitacion->id] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php
                    $inicio = \Carbon\Carbon::parse($reserva->fecha_ingreso)->toDateString();
                    $fin = \Carbon\Carbon::parse($reserva->fecha_egreso)->toDateString();
                    $estado = $reserva->estado_reserva;
                    $pagada = $reserva->estado_pago === 'Pagado';
                    $usuario = $reserva->usuario->name ?? 'Cliente';

                    $colInicio = $fechas->search(fn($fecha) => $fecha->toDateString() === $inicio);
                    $colFin = $fechas->search(fn($fecha) => $fecha->toDateString() === $fin);

                    // Si la fecha de egreso no está en el array, asumimos que termina en el último día del calendario
                    if ($colFin === false) {
                    $colFin = $fechas->count(); // una columna más allá del final
                    }

                    if ($colInicio !== false && $colFin > $colInicio) {
                    $colSpan = $colFin - $colInicio;
                    // Renderizamos la pill normalmente
                    }
                    ?>

                    <?php if($colInicio !== false && $colFin !== false): ?>
                    <div
                        class="pill-reserva"
                        data-id="<?php echo e($reserva->id); ?>"
                        data-start="<?php echo e($colInicio); ?>"
                        data-span="<?php echo e($colSpan); ?>"
                        data-habitacion-id="<?php echo e($habitacion->id); ?>"
                        data-color="<?php echo e($estado); ?>"
                        data-pagada="<?php echo e($pagada ? '1' : '0'); ?>"
                        data-usuario="<?php echo e($usuario); ?>">
                        <?php echo e($usuario); ?>

                        <?php if (! ($pagada)): ?>
                        <span class="dot-pago-pendiente"></span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

        </div>
    </div>
    </div>

    
    <div id="modalCalendario" class="hidden fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
        <div class="bg-white text-gray-800 p-6 rounded shadow-lg max-w-md w-full relative">
            <h2 class="text-lg font-semibold mb-4">📅 Establecer rango de calendario</h2>

            <form id="formularioCalendario" method="POST" action="<?php echo e(route('calendario.actualizar-rango')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(session('error')): ?>
                <div id="alerta-error-calendario" class="bg-red-100 border border-red-400 text-red-800 px-4 py-2 rounded mb-4 text-sm shadow">
                    ⚠️ <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>

                <label class="block mb-2 font-medium">Fecha desde:</label>
                <input type="date" name="fecha_inicio" class="border px-3 py-2 rounded w-full mb-4" required>

                <label class="block mb-2 font-medium">Fecha hasta:</label>
                <input type="date" name="fecha_fin" class="border px-3 py-2 rounded w-full mb-4" required>

                <div class="flex justify-end gap-2 mt-4">
                    <button type="button" onclick="cerrarFormularioCalendario()"
                        class="px-4 py-2 bg-gray-300 text-gray-800 rounded">Cancelar</button>
                    <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                        Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
    <?php if(session('error')): ?>
    <script>
        window.addEventListener('DOMContentLoaded', () => {
            if (typeof mostrarFormularioCalendario === 'function') {
                mostrarFormularioCalendario();
            }
        });
    </script>
    <?php endif; ?>
    
    <div id="menu-contextual-reserva"
        class="hidden absolute bg-white border rounded shadow-lg text-sm z-50 w-48"
        style="display: none">
        <ul>
            <li><a href="#" class="px-4 py-2 block text-black hover:bg-gray-100" id="btn-detalle">Ver Detalles</a></li>
            <li><button class="w-full text-left px-4 py-2 text-black hover:bg-gray-100" id="btn-checkin">Hacer Check-in</button></li>
            <li><button class="w-full text-left px-4 py-2 text-black hover:bg-gray-100" id="btn-checkout">Hacer Check-out</button></li>
            <li><button class="w-full text-left px-4 py-2 text-black text-red-600 hover:bg-red-100" id="btn-cancelar">Cancelar</button></li>
            <li><button class="w-full text-left px-4 py-2 text-black hover:bg-gray-100" id="btn-dejar-pendiente">Dejar Pendiente</button></li>
        </ul>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/backoffice/calendario/index.blade.php ENDPATH**/ ?>