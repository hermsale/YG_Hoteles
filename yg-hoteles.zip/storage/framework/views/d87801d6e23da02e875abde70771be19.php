<!-- app-layout es el navbar  -->
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php if (isset($component)) { $__componentOriginalc2d9560d8fda50e90dac1a59ed364cb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2d9560d8fda50e90dac1a59ed364cb0 = $attributes; } ?>
<?php $component = App\View\Components\FormularioReserva::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formulario-reserva'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormularioReserva::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2d9560d8fda50e90dac1a59ed364cb0)): ?>
<?php $attributes = $__attributesOriginalc2d9560d8fda50e90dac1a59ed364cb0; ?>
<?php unset($__attributesOriginalc2d9560d8fda50e90dac1a59ed364cb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2d9560d8fda50e90dac1a59ed364cb0)): ?>
<?php $component = $__componentOriginalc2d9560d8fda50e90dac1a59ed364cb0; ?>
<?php unset($__componentOriginalc2d9560d8fda50e90dac1a59ed364cb0); ?>
<?php endif; ?>

    <!-- cito el componente de navbar -->
    <?php if (isset($component)) { $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e = $attributes; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $attributes = $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $component = $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>

    
    <section class="px-8 py-12 bg-gray-900">
        <div class="max-w-6xl mx-auto px-4">

            <h2 class="text-3xl font-bold mb-4">YG Hoteles – Confort y naturaleza en Las Leñas</h2>
            <p class="mb-4">
                Ubicado en el corazón de Las Leñas, YGHoteles ofrece la combinación perfecta entre comodidad y naturaleza.
                Con 15 habitaciones, el hotel brinda un ambiente cálido y acogedor para disfrutar de la tranquilidad de la
                montaña.
            </p>
            <p class="mb-4">
                Situado a pocos minutos de los principales centros de esquí y actividades al aire libre, el hotel es ideal
                para quienes
                buscan aventura en la nieve o simplemente relajarse con vistas impresionantes.
            </p>
            <p class="mb-4">
                Las habitaciones de YGHoteles cuentan con detalles de calidad, algunas incluyen ventanales panorámicos con
                vista a la
                montaña, minibar y una zona de descanso. Todas están equipadas con ventanas insonorizadas, escritorio,
                calefacción y baño
                privado con ducha y artículos de tocador.
            </p>
            <p class="mb-6">
                Ya sea para una escapada en pareja, un viaje en familia o una aventura en la nieve, YGHoteles te ofrece el
                mejor refugio
                en Las Leñas. ¡Te esperamos!
            </p>

            <div class="flex justify-center">
                <img src="<?php echo e(asset('img/otros/descripcion-ubicacion-2.png')); ?>" alt="Mapa de ubicación"
                    class="rounded shadow-md w-full max-w-3xl">
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/welcome.blade.php ENDPATH**/ ?>