<?php
    $current = Route::currentRouteName();
?>

<nav class="bg-gray-800 text-center py-3">
    <div class="inline-flex rounded overflow-hidden shadow-lg">
        <a href="<?php echo e(route('welcome')); ?>"
           class="<?php echo e($current === 'welcome' ? 'bg-blue-500' : 'bg-gray-700 hover:bg-gray-600'); ?> px-4 py-2">
           Descripción
        </a>
        <a href="<?php echo e(route('habitaciones.index')); ?>"
           class="<?php echo e($current === 'habitaciones.index' || $current === 'habitaciones.disponibilidad'  ? 'bg-blue-500' : 'bg-gray-700 hover:bg-gray-600'); ?> px-4 py-2">
           Habitaciones
        </a>
          <a href="<?php echo e(route('fotos.index')); ?>"
           class="<?php echo e($current === 'fotos.index' ? 'bg-blue-500' : 'bg-gray-700 hover:bg-gray-600'); ?> px-4 py-2">
           Fotos
        </a>
        <a href="<?php echo e(route('resenia.index')); ?>"
           class="<?php echo e($current === 'resenia.index' ? 'bg-blue-500' : 'bg-gray-700 hover:bg-gray-600'); ?> px-4 py-2">
           Reseñas
        </a>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/components/navbar.blade.php ENDPATH**/ ?>