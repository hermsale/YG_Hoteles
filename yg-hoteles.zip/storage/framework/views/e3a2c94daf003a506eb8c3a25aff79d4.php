<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="relative min-h-screen bg-cover bg-center" style="background-image: url('<?php echo e(asset('img/otros/fondo-inicio.png')); ?>');">
        <div class="py-24 bg-black bg-opacity-50">
            <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="bg-white rounded-2xl shadow-xl p-8">

                    
                    <h2 class="text-xl font-bold mb-4 text-gray-800">
                        Detalle de tu reserva
                        <?php if(auth()->check() && in_array(auth()->user()->rol->nombre_rol, ['Administrador', 'Recepcionista'])): ?>
                        <span class="text-sm font-normal text-gray-600 ml-4">
                            Cliente: <?php echo e($reserva->usuario->name ?? 'N/A'); ?>

                        </span>
                        <?php endif; ?>
                    </h2>


                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

                        
                        <div>
                            <img src="<?php echo e(asset($reserva->habitacion->imagenes->first()->url)); ?>"
                                alt="Imagen habitación"
                                class="rounded-lg shadow-md w-full h-60 object-cover">
                        </div>

                        
                        <div class="md:col-span-2 space-y-5 text-gray-800 text-sm">
                            <div>
                                <h3 class="text-xl font-semibold italic text-gray-800">
                                    Habitación N°<?php echo e($reserva->habitacion->codigo_habitacion); ?> - <?php echo e($reserva->habitacion->categoria->nombre); ?>

                                </h3>
                                <p class="text-gray-600 mt-1"><?php echo e($reserva->habitacion->descripcion); ?></p>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                <div>
                                    <span class="text-gray-500 italic">📅 Fecha Ingreso</span>
                                    <p class="font-medium"><?php echo e(\Carbon\Carbon::parse($reserva->fecha_ingreso)->format('d M. Y')); ?></p>
                                </div>
                                <div>
                                    <span class="text-gray-500 italic">📅 Fecha Egreso</span>
                                    <p class="font-medium"><?php echo e(\Carbon\Carbon::parse($reserva->fecha_egreso)->format('d M. Y')); ?></p>
                                </div>
                                <div>
                                    <span class="text-gray-500 italic">🌙 Cantidad de Noches</span>
                                    <p class="font-medium"><?php echo e($cantidadNoches ?? 'No especificado'); ?></p>
                                </div>
                                <div>
                                    <span class="text-gray-500 italic">💰 Total</span>
                                    <p class="font-medium">$<?php echo e(number_format($reserva->precio_final, 2, ',', '.')); ?> ARS</p>
                                </div>
                                <?php if($reserva->promocion): ?>
                                <?php
                                $precioOriginal = $reserva->precio_final / (1 - $reserva->promocion->descuento_porcentaje / 100);
                                ?>
                                <div class="col-span-2 bg-blue-50 text-blue-800 p-3 rounded-lg shadow mt-2">
                                    <p><strong>💸 Precio sin descuento:</strong> $<?php echo e(number_format($precioOriginal, 2, ',', '.')); ?> ARS</p>
                                    <p><strong>🎁 Promoción aplicada:</strong> <?php echo e($reserva->promocion->nombre); ?> (<?php echo e($reserva->promocion->descuento_porcentaje); ?>%)</p>
                                    <p><strong>✅ Total a pagar con descuento:</strong> $<?php echo e(number_format($reserva->precio_final, 2, ',', '.')); ?> ARS</p>
                                </div>
                                <?php else: ?>
                                <div class="col-span-2 text-gray-600 mt-2">
                                    <p><strong>💳 Total a pagar:</strong> $<?php echo e(number_format($reserva->precio_final, 2, ',', '.')); ?> ARS</p>
                                </div>
                                <?php endif; ?>
                                <div>
                                    <span class="text-gray-500 italic">📌 Estado de Reserva</span>
                                    <p class="font-semibold
                                     <?php if($reserva->estado_reserva === 'Activa'): ?> text-green-600
                                    <?php elseif($reserva->estado_reserva === 'Pendiente'): ?> text-yellow-600
                                    <?php elseif($reserva->estado_reserva === 'Finalizada'): ?> text-blue-600
                                     <?php else: ?> text-red-600 <?php endif; ?>">
                                        <?php echo e($reserva->estado_reserva); ?>

                                    </p>
                                </div>
                                <div>
                                    <span class="text-gray-500 italic">💳 Estado de Pago</span>
                                    <p class="font-semibold
                                        <?php if($reserva->estado_pago === 'Pendiente'): ?> text-yellow-600
                                        <?php elseif($reserva->estado_pago === 'Pagado'): ?> text-green-600
                                        <?php else: ?> text-red-600 <?php endif; ?>">
                                        <?php echo e($reserva->estado_pago); ?>

                                    </p>
                                </div>
                            </div>


                            
                            <div class="flex flex-col sm:flex-row gap-4 mt-6">
                                <?php if(session('success')): ?>
                                <div
                                    x-data="{ show: true }"
                                    x-init="setTimeout(() => show = false, 3000)"
                                    x-show="show"
                                    x-transition
                                    class="fixed top-1/2  left-1/2 z-50 transform -translate-x-1/2 bg-green-100 border border-green-400 text-green-800 px-6 py-3 rounded-lg shadow-lg"
                                    role="alert">
                                    <strong class="font-semibold">✔ ¡Aviso enviado!</strong>
                                    <span class="block mt-1"><?php echo e(session('success')); ?></span>
                                </div>
                                <?php endif; ?>
                                <form method="POST" action="<?php echo e(route('reservas.avisoPago', $reserva->id)); ?>">
                                    <?php echo csrf_field(); ?>

                                    <!-- si el estado de reserva es pendiente y todavia no se dio aviso de pago. mostrar aviso de pago verde y habilitado -->
                                    <!-- si diste aviso de pago se deshabilita la opcion y cambia de color -->
                                    <button
                                        class="px-5 py-2 rounded-xl text-white font-semibold transition
                                        <?php if($reserva->estado_pago === 'Pendiente' && !$reserva->aviso_pago): ?>
                                             bg-green-600 hover:bg-green-700
                                                <?php else: ?>
                                                bg-gray-400 cursor-default
                                            <?php endif; ?>"
                                        <?php echo e($reserva->estado_pago === 'Cancelado' ? 'bg-gray-400  cursor-default'  : ''); ?>

                                        <?php echo e($reserva->aviso_pago ? 'disabled' : ''); ?>>
                                        Aviso de Pago
                                    </button>
                                </form>
                                <form method="POST" action="<?php echo e(route('reservas.cancelarReserva', $reserva->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button
                                        class="px-5 py-2 rounded-xl text-white font-semibold
                                            <?php echo e($reserva->estado_reserva === 'Cancelada' ? 'bg-gray-400  cursor-default'  : 'bg-red-600 hover:bg-red-700'); ?>"
                                        <?php echo e($reserva->estado_reserva === 'Cancelada' ? 'disabled' : ''); ?>>
                                        Cancelar Reserva
                                    </button>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        
        <?php if(auth()->check() && in_array(auth()->user()->rol->nombre_rol, ['Administrador', 'Recepcionista'])): ?>
        <div class="max-w-5xl mx-auto mt-8 px-4 sm:px-6 lg:px-8">
            <div class="bg-white rounded-2xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                    ✏️ Modificar Fechas de la Reserva
                </h3>

                <?php if(session('success')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-800 px-4 py-3 rounded">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('reservas.actualizarFechas', $reserva->id)); ?>"
                    class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div>
                        <label class="block text-sm font-medium text-gray-600 mb-1">📅 Nueva Fecha Ingreso</label>
                        <input type="date" name="fecha_ingreso"
                            value="<?php echo e(\Carbon\Carbon::parse($reserva->fecha_ingreso)->format('Y-m-d')); ?>"
                            class="w-full border-gray-300 text-black rounded px-3 py-2 shadow-sm text-sm" required>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-600 mb-1">📅 Nueva Fecha Egreso</label>
                        <input type="date" name="fecha_egreso"
                            value="<?php echo e(\Carbon\Carbon::parse($reserva->fecha_egreso)->format('Y-m-d')); ?>"
                            class="w-full border-gray-300 text-black rounded px-3 py-2 shadow-sm text-sm" required>
                    </div>

                    <div class="col-span-2 flex justify-center">
                        <button type="submit"
                            class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 mt-3 rounded shadow-sm font-medium">
                            Guardar Cambios
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>


        
        <?php if(auth()->check() && in_array(auth()->user()->rol->nombre_rol, ['Administrador', 'Recepcionista'])): ?>
        <div class="max-w-5xl mx-auto mt-8 px-4 sm:px-6 lg:px-8">
            <div class="bg-white rounded-2xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                    💰 Modificar Total a Pagar
                </h3>

                <?php if(session('success_total')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-800 px-4 py-3 rounded">
                    <?php echo e(session('success_total')); ?>

                </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('reservas.actualizarTotal', $reserva->id)); ?>" class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="col-span-2">
                        <label class="block text-sm font-medium text-gray-600 mb-1">💵 Nuevo Total (ARS)</label>
                        <input type="number" name="precio_final" min="0" step="0.01"
                            value="<?php echo e($reserva->precio_final); ?>"
                            class="w-full border-gray-300 rounded px-3 py-2 shadow-sm text-sm text-gray-800" required>
                    </div>

                    <div class="col-span-2 flex justify-center">
                        <button type="submit"
                            class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 mt-3 rounded shadow-sm font-medium">
                            Guardar Total
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if(auth()->check() && in_array(auth()->user()->rol->nombre_rol, ['Administrador', 'Recepcionista'])): ?>
                <div class="max-w-5xl mx-auto mt-8 px-4 sm:px-6 lg:px-8">
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                            📌 Cambiar Estado de la Reserva
                        </h3>

                        <?php if(session('success_estado')): ?>
                            <div class="mb-4 bg-green-100 border border-green-400 text-green-800 px-4 py-3 rounded">
                                <?php echo e(session('success_estado')); ?>

                            </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('reservas.actualizarEstado', $reserva->id)); ?>"
                            class="grid grid-cols-1 gap-4">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div>
                                <label class="block text-sm font-medium text-gray-600 mb-1">Nuevo Estado</label>
                                <select name="estado_reserva"
                                        class="w-full border-gray-300 rounded px-3 py-2 shadow-sm text-sm text-gray-800"
                                        required>
                                    <?php $__currentLoopData = ['Activa', 'Finalizada', 'Cancelada', 'Pendiente']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($estado); ?>" <?php if($reserva->estado_reserva === $estado): ?> selected <?php endif; ?>>
                                            <?php echo e($estado); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="flex justify-center">
                                <button type="submit"
                                        class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 mt-3 rounded shadow-sm font-medium">
                                    Guardar Estado
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

        
        <?php if(auth()->check() && in_array(auth()->user()->rol->nombre_rol, ['Administrador', 'Recepcionista'])): ?>
        <div class="max-w-5xl mx-auto mt-8 px-4 sm:px-6 lg:px-8">
            <div class="bg-white rounded-2xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                    💳 Cambiar Estado de Pago
                </h3>

                <?php if(session('success_pago')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-800 px-4 py-3 rounded">
                    <?php echo e(session('success_pago')); ?>

                </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('reservas.actualizarPago', $reserva->id)); ?>"
                    class="grid grid-cols-1 gap-4">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div>
                        <label class="block text-sm font-medium text-gray-600 mb-1">Nuevo Estado de Pago</label>
                        <select name="estado_pago"
                            class="w-full border-gray-300 rounded px-3 py-2 shadow-sm text-sm text-gray-800"
                            required>
                            <?php $__currentLoopData = ['Pendiente', 'Pagado', 'Cancelado']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($estado); ?>" <?php if($reserva->estado_pago === $estado): ?> selected <?php endif; ?>>
                                <?php echo e($estado); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="flex justify-center">
                        <button type="submit"
                            class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 mt-3 rounded shadow-sm font-medium">
                            Guardar Estado de Pago
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if(auth()->check() && in_array(auth()->user()->rol->nombre_rol, ['Administrador', 'Recepcionista'])): ?>
        <div class="max-w-5xl mx-auto mt-8 px-4 sm:px-6 lg:px-8">
            <div class="bg-white rounded-2xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-red-700 mb-4 flex items-center gap-2">
                    🗑 Eliminar Reserva
                </h3>

                <?php if(session('success_eliminar')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-800 px-4 py-3 rounded">
                    <?php echo e(session('success_eliminar')); ?>

                </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                <div class="mb-4 bg-red-100 border border-red-400 text-red-800 px-4 py-3 rounded">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('reservas.eliminar', $reserva->id)); ?>"
                    onsubmit="return confirm('¿Estás seguro de que querés eliminar esta reserva?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <div class="flex justify-center">
                        <button type="submit"
                            class="bg-red-600 hover:bg-red-700 text-white px-5 py-2 mt-3 rounded shadow-sm font-medium">
                            Eliminar Reserva
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/cliente/reservas/detalle.blade.php ENDPATH**/ ?>