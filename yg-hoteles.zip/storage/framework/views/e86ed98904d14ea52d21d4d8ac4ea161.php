<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="relative min-h-screen bg-cover bg-center"
        style="background-image: url('<?php echo e(asset('img/otros/fondo-inicio.png')); ?>');">
        <div class="py-24 bg-black bg-opacity-50">
            <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="bg-white shadow-xl rounded-2xl p-8">

                    
                    <h2 class="text-2xl font-bold text-gray-800 mb-6">
                        📋 Confirmar Reserva
                    </h2>

                    <p class="text-gray-600 mb-4">
                        Estás a punto de reservar la siguiente habitación. Por favor, revisá los datos antes de confirmar.
                    </p>

                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 items-start mb-8">
                        
                        <div>
                            <img src="<?php echo e(asset($habitacion->imagenes->first()->url)); ?>"
                                 alt="Imagen habitación"
                                 class="rounded-lg shadow-md w-full h-64 object-cover">
                        </div>

                        
                        <div class="md:col-span-2 space-y-4 text-gray-800 text-sm">
                            <div>
                                <h3 class="text-lg font-semibold italic">
                                    Habitación N° <?php echo e($habitacion->codigo_habitacion); ?>

                                </h3>
                            </div>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <span class="text-gray-500 italic">📅 Fecha Ingreso</span>
                                    <p class="font-medium"><?php echo e($fechaEntrada); ?></p>
                                </div>
                                <div>
                                    <span class="text-gray-500 italic">📅 Fecha Egreso</span>
                                    <p class="font-medium"><?php echo e($fechaSalida); ?></p>
                                </div>
                                <div>
                                    <span class="text-gray-500 italic">🌙 Cantidad de Noches</span>
                                    <p class="font-medium"><?php echo e($cantidadNoches); ?></p>
                                </div>
                                <div>
                                    <span class="text-gray-500 italic">💳 Importe Total</span>
                                    <p class="font-medium">$<?php echo e(number_format($importeTotal, 2, ',', '.')); ?> ARS</p>
                                </div>
                                <div>
                                    <span class="text-gray-500 italic">👤 Capacidad Máxima</span>
                                    <p class="font-medium"><?php echo e($habitacion->capacidad); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <form method="POST" action="<?php echo e(route('reservas.confirmarYGuardar')); ?>">
                        <?php echo csrf_field(); ?>
                        
                        <input type="hidden" name="habitacion_id" value="<?php echo e($habitacion->id); ?>">
                        <input type="hidden" name="fecha_ingreso" value="<?php echo e($fechaEntrada); ?>">
                        <input type="hidden" name="fecha_egreso" value="<?php echo e($fechaSalida); ?>">
                        <input type="hidden" name="precio_total" value="<?php echo e($importeTotal); ?>">

                        <div class="flex flex-col sm:flex-row gap-4">
                            <button type="submit"
                                class="px-5 py-2 rounded-xl shadow font-semibold text-white bg-green-600 hover:bg-green-700 transition">
                                ✅ Confirmar Reserva
                            </button>

                            <a href="<?php echo e(route('habitaciones.index')); ?>"
                               class="px-5 py-2 rounded-xl shadow text-white bg-gray-500 hover:bg-gray-600 text-center transition">
                                🔙 Volver
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/cliente/reservas/confirmar.blade.php ENDPATH**/ ?>