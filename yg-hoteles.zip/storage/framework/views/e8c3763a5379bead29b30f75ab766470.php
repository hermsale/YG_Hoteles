
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    
    <div class="pt-28 px-4 md:px-6 relative">

        
        <div class="flex items-center justify-between mb-4">




            
            <h2 class="text-xl text-center font-semibold text-gray-800 mt-4">
                <?php echo e($fechaHoraActualizada); ?>

            </h2>
            <h2 class="text-xl text-center font-semibold text-gray-800 mt-4">
                DASHBOARD
            </h2>

            
            <div class="flex items-center gap-3">

                
                <a href="<?php echo e(route('calendario.index')); ?>" class="text-blue-600 hover:text-blue-800 transition-all duration-200">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 7V3M16 7V3M4 11h16M4 19h16M4 15h16M4 7h16a2 2 0 012 2v11a2 2 0 01-2 2H4a2 2 0 01-2-2V9a2 2 0 012-2z" />
                    </svg>
                </a>

                
                <a  href="<?php echo e(route('backoffice.reservas.crear')); ?> "class="bg-green-400 hover:bg-green-500 text-white font-semibold px-4 py-2 rounded-lg shadow">
                    Crear Nueva Reserva
                </a>
            </div>
        </div>

        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-center mb-6">

            
            <div class="bg-white rounded-xl p-4 shadow border">
                <p class="text-2xl font-bold text-green-600"><?php echo e($totalLlegadas); ?></p>
                <p class="text-sm text-gray-600">LLEGADAS</p>
            </div>

            
            <div class="bg-white rounded-xl p-4 shadow border">
                <p class="text-2xl font-bold text-red-600"><?php echo e($totalSalidas); ?></p>
                <p class="text-sm text-gray-600">SALIDAS</p>
            </div>

            
            <div class="bg-white rounded-xl p-4 shadow border">
                <p class="text-2xl font-bold text-blue-600"><?php echo e($totalAlojados); ?></p>
                <p class="text-sm text-gray-600">HABITACIONES RESERVADAS</p>
            </div>
        </div>

        


        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

            
            
            <div class="bg-white p-4 rounded-xl shadow border">
                <h3 class="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">Reservas</h3>

                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard-reservas');

$__html = app('livewire')->mount($__name, $__params, 'lw-2111736146-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>


            
            <div class="bg-white p-4 rounded-xl shadow border">
                <h3 class="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">Actividad de Hoy</h3>

                
                <div class="flex gap-2 mb-2 text-sm">
                    <button class="px-2 py-1 bg-blue-100 text-blue-700 rounded">Ventas</button>
                    <button class="px-2 py-1 bg-gray-100 text-gray-700 rounded">Cancelaciones</button>
                </div>

                
                <div class="grid grid-cols-3 gap-2 text-center mb-4">
                    <div>
                        <p class="text-xl font-bold">0</p>
                        <p class="text-sm text-gray-600">Reservas de Hoy</p>
                    </div>
                    <div>
                        <p class="text-xl font-bold">0</p>
                        <p class="text-sm text-gray-600">Noches de Estadía</p>
                    </div>
                    <div>
                        <p class="text-xl font-bold text-blue-600">$0.00</p>
                        <p class="text-sm text-gray-600">Ingresos</p>
                    </div>
                </div>

                
                <table class="w-full text-sm">
                    <thead>
                        <tr class="text-left text-gray-600 border-b">
                            <th>Huésped</th>
                            <th>Ingresos</th>
                            <th>Llegada</th>
                            <th>Noches</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="py-2 text-blue-600">Nombre, Apellido</td>
                            <td>$Monto</td>
                            <td>dd/mm/aa</td>
                            <td>3 Noches</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/backoffice/dashboard/index.blade.php ENDPATH**/ ?>