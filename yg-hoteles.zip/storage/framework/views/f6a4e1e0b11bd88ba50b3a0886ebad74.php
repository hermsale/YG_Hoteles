<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
       <section class="bg-gray-900 text-white pt-32 pb-16">
           <div class="max-w-6xl mx-auto px-4">
               <div class="flex justify-between items-center mb-10">
                   <h2 class="text-3xl font-bold">Habitaciones</h2>
                   <a href="<?php echo e(route('backoffice.habitaciones.crear')); ?>"
                   class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-semibold">
                   ➕ Agregar habitación
                </a>
            </div>

            <?php $__empty_1 = true; $__currentLoopData = $habitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-gray-100 text-black rounded-lg shadow p-6 mb-10 flex flex-col md:flex-row gap-6">


                
                <?php
                $imagenPrincipal = $habitacion->imagenes->first();
                ?>

                <div class="w-full md:w-1/3">
                    <?php if($imagenPrincipal): ?>
                    <img src="<?php echo e(asset($imagenPrincipal->url)); ?>" alt="Imagen de <?php echo e($habitacion->nombre); ?>"
                        class="w-full max-h-64 object-cover rounded-lg">
                    <?php else: ?>
                    <img src="<?php echo e(asset('img/no-image.png')); ?>" alt="Sin imagen"
                        class="w-full max-h-64 object-cover rounded-lg">
                    <?php endif; ?>
                </div>

                <div class="md:w-2/3">
                    <h3 class="text-xl font-bold mb-2"><?php echo e($habitacion->nombre); ?></h3>
                    <p class="mb-4"><?php echo e($habitacion->descripcion); ?></p>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm mb-4">
                        <ul class="list-disc list-inside">
                            <p><strong>Servicios incluidos:</strong></p>
                            <?php $__empty_2 = true; $__currentLoopData = $habitacion->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <li><?php echo e($amenity->nombre); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <li>Sin servicios listados</li>
                            <?php endif; ?>
                        </ul>
                        <div>
                            <p>Capacidad de huéspedes: <strong><?php echo e($habitacion->capacidad); ?></strong></p>
                            <p>Categoría: <strong><?php echo e($habitacion->categoria->nombre ?? 'Sin categoría'); ?></strong></p>
                            <p>Código habitación: <strong><?php echo e($habitacion->codigo_habitacion); ?></strong></p>
                        </div>
                    </div>

                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mt-4">
                        <p><strong>Precio por 1 noche:</strong>
                            <span class="text-green-700 font-semibold">
                                <?php echo e(number_format($habitacion->precio_noche, 2, ',', '.')); ?> ARS
                            </span>
                        </p>

                        <div class="mt-4 sm:mt-0 flex gap-2">
                            <a href="<?php echo e(route('backoffice.habitaciones.editar', $habitacion->id)); ?>"
                                class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm">
                                ✏️ Editar
                            </a>


                            <?php if($habitacion->estado === 'Activo'): ?>
                            <form action="<?php echo e(route('backoffice.habitaciones.inhabilitar', $habitacion)); ?>" method="POST"
                                onsubmit="return confirm('¿Estás seguro de que deseas pausar esta habitación?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <button type="submit"
                                    class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm">
                                    💤 Pausar
                                </button>
                            </form>
                            <?php else: ?>
                            <form action="<?php echo e(route('backoffice.habitaciones.habilitar', $habitacion)); ?>" method="POST"
                                onsubmit="return confirm('¿Estás seguro de que deseas habilitar esta habitación?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <button type="submit"
                                    class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm">
                                    ✅ Habilitar
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-center text-gray-300 mt-10">No hay habitaciones registradas aún.</p>
            <?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/backoffice/habitaciones/index.blade.php ENDPATH**/ ?>