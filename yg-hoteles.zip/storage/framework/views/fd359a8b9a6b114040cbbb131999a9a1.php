<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- formulario de reserva -->
    <?php if (isset($component)) { $__componentOriginalc2d9560d8fda50e90dac1a59ed364cb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2d9560d8fda50e90dac1a59ed364cb0 = $attributes; } ?>
<?php $component = App\View\Components\FormularioReserva::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('formulario-reserva'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormularioReserva::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2d9560d8fda50e90dac1a59ed364cb0)): ?>
<?php $attributes = $__attributesOriginalc2d9560d8fda50e90dac1a59ed364cb0; ?>
<?php unset($__attributesOriginalc2d9560d8fda50e90dac1a59ed364cb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2d9560d8fda50e90dac1a59ed364cb0)): ?>
<?php $component = $__componentOriginalc2d9560d8fda50e90dac1a59ed364cb0; ?>
<?php unset($__componentOriginalc2d9560d8fda50e90dac1a59ed364cb0); ?>
<?php endif; ?>


    <!-- cito el componente de navbar -->
    <?php if (isset($component)) { $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e = $attributes; } ?>
<?php $component = App\View\Components\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $attributes = $__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__attributesOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e)): ?>
<?php $component = $__componentOriginalb9eddf53444261b5c229e9d8b9f1298e; ?>
<?php unset($__componentOriginalb9eddf53444261b5c229e9d8b9f1298e); ?>
<?php endif; ?>

    <!-- Sección de habitaciones -->
    <section class="bg-gray-900 text-white py-16">
        <div id="habitacionesDisponibles" class="max-w-6xl mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-6">Detalles y Precios</h2>
            <p class="text-center max-w-6xl mx-auto mb-12">
                YGHoteles ofrece 15 exclusivas habitaciones diseñadas para brindar confort y descanso en el corazón de Las Leñas. Algunas de ellas cuentan con balcones privados con vista a las montañas, y están equipadas con minibar y zona de comedor para quienes prefieren opciones de autoservicio.
                Cada habitación ha sido cuidadosamente insonorizada e incluye un amplio escritorio, ideal tanto para el relax como para el trabajo. Los baños están equipados con bañera y ducha, además de artículos de tocador de cortesía. Algunas habitaciones también ofrecen vistas panorámicas al entorno natural de la cordillera, creando una experiencia única de conexión con la montaña.
            </p>
            <!-- class="h-10 w-10 text-yellow-500"  -->
            <!-- esto se ejecuta si no hay habitaciones disponibles para la fecha -->
            <?php if($habitaciones->isEmpty()): ?>
            <div class="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg shadow-md text-yellow-800 mt-8 max-w-2xl mx-auto text-center">
                <div class="flex flex-col items-center space-y-4">
                    <img src="<?php echo e(asset('img/otros/no-se-encontro.png')); ?>" alt="Imagen de no se encontro" class="w-full md:w-1/3 max-h-64 object-cover rounded-lg">

                    <h3 class="text-xl font-semibold">No se encontraron habitaciones disponibles</h3>
                    <p class="text-sm text-gray-700">
                        Lo sentimos, no hay habitaciones que coincidan con los parámetros seleccionados.
                        Te recomendamos modificar las fechas o la cantidad de huéspedes e intentarlo nuevamente.
                    </p>

                    <a href="<?php echo e(route('habitaciones.index')); ?>"
                        class="mt-4 inline-block bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded shadow">
                        Cambiar búsqueda
                    </a>
                </div>
            </div>
            <?php endif; ?>

            <?php $__currentLoopData = $habitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-gray-100 text-black rounded-lg shadow p-6 mb-10 flex flex-col md:flex-row gap-6">
                
                <?php
                $imagenPrincipal = $habitacion->imagenes->first();
                ?>

                <?php if($imagenPrincipal): ?>
                <img src="<?php echo e(asset($imagenPrincipal->url)); ?>" alt="Imagen de <?php echo e($habitacion->nombre); ?>" class="w-full md:w-1/3 max-h-64 object-cover rounded-lg">
                <?php else: ?>
                <img src="<?php echo e(asset('img/no-image.png')); ?>" alt="Sin imagen" class="w-full md:w-1/3 rounded-lg object-cover">
                <?php endif; ?>

                <div class="md:w-2/3">
                    <h3 class="text-xl font-bold mb-2"><?php echo e($habitacion->nombre); ?></h3>

                    <p class="mb-4">
                        <?php echo e($habitacion->descripcion); ?>

                    </p>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm mb-4">
                        <ul class="list-disc list-inside">
                            <p><strong>Servicios incluidos:</strong></p>
                            <?php $__empty_1 = true; $__currentLoopData = $habitacion->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><?php echo e($amenity->nombre); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li>Sin servicios listados</li>
                            <?php endif; ?>
                        </ul>

                        <div>
                            <p>Capacidad de huéspedes: <strong><?php echo e($habitacion->capacidad); ?></strong></p>
                            <p>Categoría: <strong><?php echo e($habitacion->categoria->nombre ?? 'Sin categoría'); ?></strong></p>
                            <p>Código habitación: <strong><?php echo e($habitacion->codigo_habitacion); ?></strong></p>
                        </div>
                    </div>

                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                        <p><strong>Precio por 1 noche:</strong>
                            <span class="text-green-700 font-semibold">
                                <?php echo e(number_format($habitacion->precio_noche, 2, ',', '.')); ?> ARS
                            </span>
                        </p>
                        <a href="<?php echo e(route('reservas.confirmar', [
                                                        'habitacion_id' => $habitacion->id,
                                                        'fecha_entrada' => request('fecha_entrada'),
                                                        'fecha_salida' => request('fecha_salida'),
                                                        'huespedes' => request('huespedes'),
                                ])); ?>" class="mt-2 sm:mt-0 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                            Reservar Ahora
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>



    </section>
    <!-- si detecta que se realizo una busqueda. scrollea para abajo -->
    <?php if(request()->has('fecha_entrada') && request()->has('fecha_salida')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const seccion = document.getElementById("habitacionesDisponibles");
            if (seccion) {
                seccion.scrollIntoView({
                    behavior: "smooth"
                });
            }
        });
    </script>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ProduccionWeb\YG_Hoteles\resources\views/cliente/habitaciones/disponibilidad.blade.php ENDPATH**/ ?>